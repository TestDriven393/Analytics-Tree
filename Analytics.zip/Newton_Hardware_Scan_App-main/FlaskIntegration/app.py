from flask import Flask, render_template, request, redirect, session
import requests

app = Flask(__name__)
app.secret_key = 'your_secret_key'


@app.route('/')
def serve_react_app():
    return render_template("index.html")

 
@app.route('/authenticate', methods=['POST'])
def authenticate():
    username = request.form['username']
    password = request.form['password']

    # Make a request to the external API to authenticate
    # and retrieve the token
    response = requests.post('https://api-preview.newtoninsights.app/user/login/', json={'email': username, 'password': password})

    if response.status_code == 200:
        token = response.json().get('token')
        # Store the token in the session
        session['token'] = token
        return redirect('/scan_hardware_view')

    else:
        return 'Authentication Failed'


@app.route('/scan_hardware')
def scan_hardware():
    # Retrieve the token from the session
    token = session.get('token')

    # Check if the user is authenticated
    if token:
        # Perform the scan hardware functionality here
        return 'Hardware scanning in progress...'
    else:
        return redirect('/')


@app.route('/scan_hardware_view')
def scan_hardware_view():
    # Retrieve the token from the session
    token = session.get('token')

    # Check if the user is authenticated
    if token:
        # Perform the scan hardware functionality here
        return render_template('scan_hardware.html')
    else:
        return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)
