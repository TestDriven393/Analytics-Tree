# Newton_Hardware_Scan_App
To run reactjs app in Flask, follow following steps
1- cd FlaskIntegration
2- py app.py
