import React from 'react'

const Example = React.lazy(() => import('./views/Example/Example'))
const AirReference = React.lazy(() => import('./views/AirReference/AirReference'))
const Solvent = React.lazy(() => import('./views/Solvent/Solvent'))

const routes = [
  { path: '/', exact: true, name: 'Home' },
  { path: '/AirReference', name: 'AirReference', element: AirReference },
  { path: '/Solvent', name: 'Solvent', element: Solvent },
  { path: '/Example', name: 'Example', element: Example },
]

export default routes
