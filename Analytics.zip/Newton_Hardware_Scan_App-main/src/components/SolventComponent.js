/* eslint-disable prettier/prettier */

import React, { useState } from 'react'
import axios from 'axios'
import { Confirm } from 'react-st-modal'
import { Navigate } from 'react-router-dom'
import { Link, useNavigate } from 'react-router-dom'
const SolventComponent = () => {
  const navigate = useNavigate()

  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)

  const handleScanHardware = async () => {
    setLoading(true)

    try {
      const response = await axios.get('/scan_hardware')
      setResult(response.data)

      // Show the result in a Confirm dialog
      const confirmation = await Confirm(response.data, 'Scan Result')
    } catch (error) {
      setError('Error occurred during hardware scanning.')

      // Show the error message in a Confirm dialog
      const confirmation = await Confirm(error.message, 'Error')
    }

    setLoading(false)
  }

  return (
    <div>
      <button onClick={handleScanHardware} disabled={loading}>
        Scan Hardware
      </button>

      {loading && <p>Loading...</p>}
      {result && <p>{result}</p>}
      {error && <p>{error}</p>}
    </div>
  )
}

export default SolventComponent
