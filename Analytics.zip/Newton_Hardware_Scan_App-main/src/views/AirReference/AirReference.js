/* eslint-disable prettier/prettier */
import React, { useState } from 'react'
import axios from 'axios'
import { Confirm } from 'react-st-modal'
import { Navigate } from 'react-router-dom'
import { CButton } from '@coreui/react'

import { Link, useNavigate } from 'react-router-dom'
import SolventComponent from '../../components/SolventComponent'
const AirReference = () => {
  const navigate = useNavigate()

  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)

  const handleScanHardware = async () => {
    setLoading(true)

    try {
      const response = await axios.get('http://localhost:5000/scan_hardware')
      setResult(response.data)

      // Show the result in a Confirm dialog
      const confirmation = await Confirm(response.data, 'Scan Result')

      if (confirmation === 'OK') {
        // Navigate to "/Solvent"
        navigate('/Solvent')
      }
    } catch (error) {
      setError('Error occurred during hardware scanning.')

      // Show the error message in a Confirm dialog
      const confirmation = await Confirm(error.message, 'Error')

      if (confirmation === 'OK') {
        // Navigate to "/Solvent"
        navigate('/SolventComponent')
      }
    }

    setLoading(false)
  }

  return (
    <div>
      <CButton color="primary" onClick={handleScanHardware} disabled={loading} className="mb-3">
        Scan Hardware
      </CButton>

      {loading && <p>Loading...</p>}
      {result && <p>{result}</p>}
      {error && <p>{error}</p>}
    </div>
  )
}

export default AirReference
